/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SWITCHCASE;

/**
 *
 * @author kiki
 */
public class Kerucut {
    private int Jari ;
    private int Tinggi ;
    
    public void setJari (int jari)
    {
        this.Jari = jari ;
    }
    public void setTinggi(int tinggi) 
    {
        this.Tinggi = tinggi ;    
    }
    public int getJari()
    {
        return Jari;
    }
    public int getTinggi()
    {
        return Tinggi;
    }
    public double HitungVolume ()
    {
        double volume;
        volume = 1/3*Jari*Jari*Tinggi;
        return volume ;
                
    }

    void set(int parseInt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
