/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SWITCHCASE;

/**
 *
 * @author kiki
 */
public class Kubus {
    static String getluas() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    private int Sisi;
    
    public void setSisi (int sisi)
    {
        this.Sisi = sisi;
    }
    public int getSisi()
    {
        return Sisi;
    }
    public double HitungLuas()
    {
        double luas;
        luas = (6*Sisi) + (Sisi*Sisi*Sisi);
        return luas;
       
    }
    public double HitungVolume ()
    {
        double Volume;
        Volume = Sisi*Sisi*Sisi;
        return Volume ;
                
    }
    
    
}
