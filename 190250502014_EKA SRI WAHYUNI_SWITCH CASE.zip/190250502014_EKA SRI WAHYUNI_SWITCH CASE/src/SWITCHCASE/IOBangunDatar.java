/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SWITCHCASE;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 *
 * @author kiki
 */
public class IOBangunDatar {
    public static void main(String[] args) {
        String pilih; 
        Scanner  Scan = new Scanner(System.in);
        BufferedReader datain = new BufferedReader (new InputStreamReader(System.in));
        Prisma prisma = new Prisma();
        Kerucut kerucut = new Kerucut();
        Kubus kubus = new Kubus();
        Limas limas = new Limas();
        Tabung tabung = new Tabung();
         try{
             
             System.out.println("SELAMAT DATANG DI PROGRAM BANGUN DATAR");
             System.out.println("1. HITUNG PRISMA");
             System.out.println("2. HITUNG KRUCUT");
             System.out.println("3. HITUNG KUBUS");
             System.out.println("4. HITUNG LIMAS");
             System.out.println("5. HITUNG TABUNG");
             pilih = Scan.nextLine();
             switch (1){
                 case (1):
                     System.out.println("Anda menghitung prisma");
                     System.out.println("masukan nilai alas");
                     String a = datain.readLine();
                    
                    
            
                     System.out.println("masukkan nilai keliling :");
                     String b = datain.readLine();
                     prisma.setkeliling(Integer.parseInt(b));
            
                     
                     
                     System.out.println("Alas ="+prisma.getalas());
                     System.out.println("Keliling="+prisma.getkeliling());
                     System.out.println("Tinggi ="+prisma.gettinggi());
                     System.out.println("Luas ="+prisma.HitungLuas());
                     System.out.println("Volume="+prisma.HitungVolume());
                     break;
                 
                 case (2):
                      System.out.println("Anda menghitung Kerucut");
                      System.out.println("masukkan nilai Jari-jari :");
                      String c = datain.readLine();
                      kerucut.setJari(Integer.parseInt(c));
            
                      System.out.println("masukkan nilai Tinggi :");
                      String d = datain.readLine();
                      kerucut.set(Integer.parseInt(d));
            
                      System.out.println("jari-jari ="+kerucut.getJari());
                      System.out.println("tinggi ="+kerucut.getTinggi());
                      System.out.println("volume ="+kerucut.HitungVolume());
                      break;
                      
                 case (3):
                      System.out.println("Anda menghitung Kubus");
                      System.out.println("masukkan nilai Sisi :");
                      String e = datain.readLine();
                      kubus.setSisi(Integer.parseInt(e));
              
                      System.out.println("Sisi Kubus  ="+kubus.getSisi());
                      System.out.println("Luas Kubus ="+Kubus.getluas());
                      System.out.println("Volume Kubus ="+kubus.HitungVolume());
                      break;
                      
                  case(4):
                      System.out.println(" Anda Menghitung limas");
                      System.out.println("masukkan nilai luas :");
                      String f = datain.readLine();
                      limas.setLuas(Integer.parseInt(f));
                      
                      System.out.println("masukkan nilai Tinggi :");
                      String g = datain.readLine();
                      limas.setTinggi(Integer.parseInt(g));
            
                      System.out.println("Luas Limas ="+limas.getLuas());
                      System.out.println("Tinggi Limas ="+limas.getTinggi());
                      System.out.println("volume Limas ="+limas.HitungVolume());
                      break;
                      
                  case (5):
                      System.out.println("Anda Menghitung tabung");
                      System.out.println("masukkan nilai tinggi :");
                      String h = datain.readLine();
                      tabung.setTinggi(Integer.parseInt(h));
            
                      System.out.println("masukkan nilai jari-jari :");
                      String i = datain.readLine();
                      tabung.setJari(Integer.parseInt(i));
            
                      System.out.println("Tinggi Tabung ="+tabung.getTinggi());
                      System.out.println("Jari-jari Tabung ="+tabung.getJari());
                      System.out.println("Luas Tabung ="+tabung.HitungLuasAlas());
                      System.out.println("Volume Tabung ="+tabung.Hitungvolume());
                      System.out.println("Keliling Tabung ="+tabung.HitungKeliling());
                      break;          
             }
              }
              catch (IOException e)
              {
        
             
    }
    }
    
    }
    

